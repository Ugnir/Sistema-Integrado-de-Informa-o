$('.more').click(function(){
  $(this).closest("tr").find(".oculta").slideToggle();   
});
$('.allAppear').click(function(){
  $(".aparecerGeral").slideToggle();   
});

$(document).ready(function(){
 $('.modal-alterpt').on('click', function(event) {
  var dataid = $(this).attr('data-id');
  $('#cores-'+dataid).modal({
    show: true
  });
});
 $('.submit-criticidade').on('click', function(event) {
  event.preventDefault();
  var form = $(this).closest('form');

  var formulario = form.serialize();
  console.log('formulario',formulario);
  $.ajax({
    type: "POST",
    url: 'consCriticidade_ajax.php',
    data: formulario,
    dataType:'json',
    cache: false,
    success: function (data) {
      console.log(data.numeropt);
      $('.modal-alterpt[data-id="'+data.id_linha+'"]')
        .text(data.numeropt)
        .removeClass()
        .addClass('modal-alterpt')
        .addClass('criticidade-'+data.criticidade);
    }
  });
});
 $('.giop').on('change', function(event) {
  event.preventDefault();
    // pega o form mais proximo do definido(neste caso select-change)
    var form = $(this).closest('form');

    var trocar = $(this).val();

    var formulario = form.serialize();
    console.log('formulario',formulario);
    $.post("seletorOper_ajax.php", formulario,function(data){
    });
  });
 $('.selecao').on('change', function(event) {
  event.preventDefault();
    // pega o form mais proximo do definido(neste caso select-change)
    var form = $(this).closest('form');

    var trocar = $(this).val();

    var formulario = form.serialize();
    console.log('formulario',formulario);
    $.post("status_ajax.php", formulario,function(data){
    });
  });
 $('.alterar').on('click', function(event) {
  event.preventDefault();
    // pega o form mais proximo do definido(neste caso select-change)
    var alt = $(this).closest('form');

    var alterar = $(this).val();

    var altform = alt.serialize();
    console.log('alterar',altform);
    $.post("consAtt_ajax.php", altform,function(data){
      if (data = 'sucess')
        alert ("Modificação realizado com sucesso, atualize a pagina para verificação.");
      else
        alert("erro");
    });
  });
 $('.submit-adicionar').on('click', function(event) {
  event.preventDefault();
  var form = $(this).closest('form');
  var formulario = form.serialize();
  console.log('formulario',formulario);
  $.ajax({
    type: "POST",
    url: 'consAdd_ajax.php',
    data: formulario,
    cache: false,
    success: function (data) {
      alert ("Adicionado com sucesso, atualize a pagina para verificação.");
    }
  });
});
 $('.submit-deletar').on('click', function(event) {
  event.preventDefault();
  var form = $(this).closest('form');
  var formulario = form.serialize();
  if (form.find(".justificativa_deletar").val()=="") {
  alert("Necessário justificativa!")
 }else{
  console.log('formulario',formulario);
  $.ajax({
    type: "POST",
    url: 'consDelet_ajax.php',
    data: formulario,
    cache: false,
    success: function (data) {
      alert ("Deletado com sucesso, atualize a pagina para verificação.");
      $(".modal").modal('hide');
      }
    });
  }
 });

  $('.seletor_fim_atividade').on('change', function(event) {
  event.preventDefault();
    var form = $(this).closest('form');
    var trocar = $(this).val();
    var formulario = form.serialize();

    console.log('formulario',formulario);
    $.post("seletor_de_finalizado_ajax.php", formulario,function(data){
    });
  });

$('.finalizada').on('click', function(event) {
  event.preventDefault();
  var form = $(this).closest('form');
  var formulario = form.serialize();
  var tr = $(this).closest('tr');

  //validação:
  console.log(form.find(".seletor_fim_atividade").val());
  if (form.find(".seletor_fim_atividade").val()=="") {
    alert("favor informar se o serviço irá continuar.")
  }
  else if (form.find(".hh_programada").val()=="") {
    alert("o campo de horas programadas é obrigatorio.")
  }
  else if (form.find(".hh_executada").val()=="") {
    alert("o campo de horas executadas é obrigatorio.")
  }
  else if (form.find(".texto_justificativa").val()=="") {
    alert("Necessario inclusão da justificativa.")
  }else{
    console.log('formulario',formulario);
    $.ajax({
      type: "POST",
      url: 'consAltera_hora_ajax.php',
      data: formulario,
      cache: false,
      success: function (data) {
        alert("Alterado e salvo com sucesso!");
        $(".modal").modal('hide');
        tr.css("background-color","DarkGray");
        tr.find(".buttongeral").prop('disabled',true);
        tr.find("select").prop('disabled',true);

      }
    });
  }
});

$('.observ').on('click', function(event) {
    event.preventDefault();
    // pega o form mais proximo do definido(neste caso select-change)
   var form = $(this).closest('form');

   var trocar = $(this).val();

   var formulario = form.serialize();
   console.log('formulario',formulario);
   $.post("observacao_ajax.php", formulario,function(data){
    alert('Observação inserida!');
   });
 });


});
