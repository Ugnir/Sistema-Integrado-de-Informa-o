<?php

$where = '';

  if(isset($_GET['pesquisa'])&& !empty($_GET['pesquisa'])){
      $where= "and (
          i.centrab LIKE '%".$_GET['pesquisa']."%' or
          i.ordem LIKE '%".$_GET['pesquisa']."%' or
          i.supervisao LIKE '%".$_GET['pesquisa']."%' or
          i.texto_breve LIKE '%".$_GET['pesquisa']."%' or
          i.status_user LIKE '%".$_GET['pesquisa']."%' or
          i.criticidade LIKE '%".$_GET['pesquisa']."%' or
          i.hora LIKE '%".$_GET['pesquisa']."% '
        )";
      // $where= "and ".$_GET['tipo']." LIKE '%".$_GET['pesquisa']."%'";
    }
  if(isset($_GET['data_inicial']) && !empty($_GET['data_inicial']) && isset($_GET['data_final']) && !empty($_GET['data_final'])) {
    $where.= " and i.dataplano BETWEEN '".$_GET['data_inicial']."' and '".$_GET['data_final']."'";

  }elseif (isset($_GET['data_inicial'])&& !empty($_GET['data_inicial'])) {
    $where.= " and i.dataplano >= '".$_GET['data_inicial']."'";

  }elseif(isset($_GET['data_final'])&& !empty($_GET['data_final'])) {
    $where.= " and i.dataplano >= '".$_GET['data_final']."'";

  }
if(isset($_GET['pesquisa'])&& !empty($_GET['pesquisa'])||isset($_GET['data_inicial']) && !empty($_GET['data_inicial']) || isset($_GET['data_final']) && !empty($_GET['data_final'])) {

  $sql="SELECT i.* FROM icpm i WHERE i.ordem <>'' AND i.campo_selecao <> ''".$where."ORDER BY i.dataplano";
  $listaOs=$pdo->query($sql); 
 }

  ?>